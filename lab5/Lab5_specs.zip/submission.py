## import modules here
import numpy as np
################# Question 1 #################

def hc(data, k):# do not change the heading of the function
    pass # Replace this line with your implementation...
